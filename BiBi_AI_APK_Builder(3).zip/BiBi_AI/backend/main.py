from pathlib import Path
from collections import defaultdict, deque
from time import monotonic
import os
import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent.parent
OLLAMA_URL = os.getenv('OLLAMA_URL', 'http://ollama:11434').rstrip('/')
MODEL = os.getenv('OLLAMA_MODEL', 'qwen3:4b-instruct')
SYSTEM_PROMPT = '''تو BiBi هستی؛ دستیار هوشمند فارسی‌زبان با شخصیت دوستانه، شوخ، خودمونی و بازیگوش. طبیعی و روان حرف بزن و وقتی مناسب است شوخی سبک داشته باش، اما کاربر را تحقیر یا آزار نده. پاسخ‌ها را روشن، مفید و مرحله‌به‌مرحله بده. برای آموزش مدرسه مثال ساده بزن. اگر چیزی را نمی‌دانی صادقانه بگو. به حریم خصوصی احترام بگذار و برای کاربر نوجوان پاسخ‌های ایمن و مناسب سن ارائه کن. زبان پاسخ را با زبان کاربر هماهنگ کن.'''
app = FastAPI(title='BiBi AI API', version='0.2.0')
_request_times = defaultdict(deque)

def enforce_rate_limit(request: Request):
    # Basic in-memory guard for the private MVP; production needs shared storage and account quotas.
    key = request.client.host if request.client else 'unknown'
    now = monotonic()
    bucket = _request_times[key]
    while bucket and now - bucket[0] > 60:
        bucket.popleft()
    if len(bucket) >= 12:
        raise HTTPException(status_code=429, detail='تعداد پیام‌ها در این دقیقه زیاد شد؛ کمی بعد دوباره امتحان کن.')
    bucket.append(now)
app.mount('/static', StaticFiles(directory=ROOT), name='static')

class Message(BaseModel):
    role: str = Field(pattern='^(user|assistant)$')
    text: str = Field(min_length=1, max_length=6000)
class ChatRequest(BaseModel):
    messages: list[Message] = Field(min_length=1, max_length=16)

@app.get('/')
async def home():
    return FileResponse(ROOT / 'index.html')

@app.get('/api/health')
async def health():
    try:
        async with httpx.AsyncClient(timeout=4.0) as client:
            response = await client.get(f'{OLLAMA_URL}/api/tags')
            response.raise_for_status()
            models = response.json().get('models', [])
        ready = any(m.get('name') == MODEL or m.get('model') == MODEL for m in models)
        return {'ok': True, 'model_ready': ready, 'model': MODEL,
                'message': 'مدل روی سرور نصب نشده است.' if not ready else 'آماده'}
    except Exception:
        return {'ok': False, 'model_ready': False, 'model': MODEL,
                'message': 'سرویس مدل در دسترس نیست.'}

@app.post('/api/chat')
async def chat(payload: ChatRequest, request: Request):
    enforce_rate_limit(request)
    messages = [{'role': 'system', 'content': SYSTEM_PROMPT}]
    messages.extend({'role': item.role, 'content': item.text} for item in payload.messages)
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(180.0, connect=8.0)) as client:
            response = await client.post(f'{OLLAMA_URL}/api/chat', json={
                'model': MODEL, 'messages': messages, 'stream': False,
                'options': {'temperature': 0.75, 'num_ctx': 8192}
            })
        if response.status_code == 404:
            raise HTTPException(status_code=503, detail='مدل هنوز روی سرور نصب نشده است. مدیر سرور باید مدل را دریافت کند.')
        response.raise_for_status()
        reply = response.json().get('message', {}).get('content', '').strip()
        if not reply:
            raise HTTPException(status_code=502, detail='مدل پاسخ خالی برگرداند.')
        return {'reply': reply, 'model': MODEL}
    except HTTPException:
        raise
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail='پاسخ‌گویی مدل طول کشید؛ دوباره تلاش کن.')
    except httpx.HTTPError:
        raise HTTPException(status_code=503, detail='اتصال به موتور هوش مصنوعی برقرار نیست.')

@app.get('/{asset_path:path}')
async def assets(asset_path: str):
    candidate = (ROOT / asset_path).resolve()
    if ROOT.resolve() not in candidate.parents or not candidate.is_file():
        raise HTTPException(status_code=404, detail='Not found')
    return FileResponse(candidate)
