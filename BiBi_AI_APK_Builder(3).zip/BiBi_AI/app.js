const form=document.querySelector('#chatForm');
const input=document.querySelector('#prompt');
const messages=document.querySelector('#messages');
const welcome=document.querySelector('#welcome');
const notice=document.querySelector('#notice');
const dialog=document.querySelector('#settingsDialog');
const statusDot=document.querySelector('#statusDot');
const statusTitle=document.querySelector('#statusTitle');
const statusText=document.querySelector('#statusText');
const modelName=document.querySelector('#modelName');
const STORAGE_KEY='bibi-chat-v1';
const installBtn=document.querySelector('#installBtn');
let installPrompt=null;
window.addEventListener('beforeinstallprompt',event=>{
  event.preventDefault(); installPrompt=event; installBtn.hidden=false;
});
installBtn?.addEventListener('click',async()=>{
  if(!installPrompt){setNotice('برای نصب، منوی سه‌نقطه Chrome را باز کن و Add to Home screen را بزن.');return;}
  installPrompt.prompt();
  await installPrompt.userChoice; installPrompt=null; installBtn.hidden=true;
});
window.addEventListener('appinstalled',()=>{installBtn.hidden=true;setNotice('BiBi روی گوشی نصب شد! ✨','ready');});

let history=[];
const SYSTEM_PROMPT=`تو BiBi هستی؛ دستیار هوشمند فارسی‌زبان با شخصیت دوستانه، شوخ، خودمونی و بازیگوش. طبیعی و روان حرف بزن و وقتی مناسب است شوخی سبک داشته باش، اما کاربر را تحقیر یا آزار نده. پاسخ‌ها را روشن، مفید و مرحله‌به‌مرحله بده. برای آموزش مدرسه مثال ساده بزن. اگر چیزی را نمی‌دانی صادقانه بگو. به حریم خصوصی احترام بگذار و برای کاربر نوجوان پاسخ‌های ایمن و مناسب سن ارائه کن. زبان پاسخ را با زبان کاربر هماهنگ کن.`;

function setNotice(text,state=''){notice.textContent=text;notice.className='notice '+state;}
function addMessage(text,kind,save=true){
  const el=document.createElement('div');el.className='message '+kind;el.textContent=text;
  messages.appendChild(el);el.scrollIntoView({behavior:'smooth',block:'end'});
  if(save) persist();return el;
}
function persist(){
  try{localStorage.setItem(STORAGE_KEY,JSON.stringify(history.slice(-40)));}catch{}
}
function renderHistory(){
  messages.replaceChildren();
  history.forEach(m=>addMessage(m.text,m.role==='user'?'user':'assistant',false));
  welcome.hidden=history.length>0;
}
async function checkServer(){
  statusTitle.textContent='در حال بررسی…';statusText.textContent='داریم وضعیت سرور را می‌پرسیم';statusDot.className='status-dot';
  try{
    const r=await fetch('/api/health',{headers:{'Accept':'application/json'}});
    const d=await r.json();
    if(!r.ok||!d.model_ready)throw new Error(d.message||'مدل هنوز آماده نیست');
    modelName.value=d.model||'مدل خودمیزبان';statusTitle.textContent='متصل و آماده';statusText.textContent='موتور هوش مصنوعی روی سرور فعال است';statusDot.className='status-dot online';
    setNotice('BiBi وصله و آماده گفت‌وگوئه ✨','ready');
  }catch(e){
    statusTitle.textContent='سرور یا مدل آماده نیست';statusText.textContent=e.message||'اتصال برقرار نشد';statusDot.className='status-dot offline';
    setNotice('موتور BiBi هنوز آماده نیست. سرور و مدل باید راه‌اندازی شوند.','error');
  }
}
async function askBiBi(){
  const r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages:history.slice(-16),system_prompt:SYSTEM_PROMPT})});
  const d=await r.json().catch(()=>({}));
  if(!r.ok)throw new Error(d.detail||'پاسخی از موتور BiBi دریافت نشد.');
  if(!d.reply)throw new Error('پاسخ خالی از سرور دریافت شد.');
  return d.reply;
}
async function sendMessage(text){
  const value=(text||'').trim();if(!value)return;
  welcome.hidden=true;history.push({role:'user',text:value});addMessage(value,'user');
  input.value='';input.style.height='auto';
  const pending=addMessage('BiBi داره فکر می‌کنه…','assistant',false);
  const send=form.querySelector('.send');send.disabled=true;
  try{
    const answer=await askBiBi();pending.textContent=answer;history.push({role:'assistant',text:answer});persist();
    setNotice('جواب از موتور خودمیزبان BiBi دریافت شد ✨','ready');
  }catch(err){
    pending.textContent='فعلاً نتونستم جواب بدم: '+err.message;
    history.pop();persist();setNotice('اتصال به موتور هوش مصنوعی برقرار نشد. وضعیت سرور را بررسی کن.','error');
  }finally{send.disabled=false;input.focus();}
}
form.addEventListener('submit',e=>{e.preventDefault();sendMessage(input.value)});
document.querySelectorAll('[data-prompt]').forEach(btn=>btn.addEventListener('click',()=>{input.value=btn.dataset.prompt;input.focus()}));
document.querySelector('#newChat').addEventListener('click',()=>{history=[];persist();renderHistory();input.value='';setNotice('گفت‌وگوی تازه شروع شد. بپرس!')});
document.querySelector('#settingsBtn').addEventListener('click',()=>{dialog.showModal();checkServer()});
document.querySelector('#checkServer').addEventListener('click',checkServer);
input.addEventListener('input',()=>{input.style.height='auto';input.style.height=Math.min(input.scrollHeight,130)+'px'});
try{history=JSON.parse(localStorage.getItem(STORAGE_KEY)||'[]');if(!Array.isArray(history))history=[];}catch{history=[];}
renderHistory();checkServer();
if('serviceWorker' in navigator && location.protocol.startsWith('http'))window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
